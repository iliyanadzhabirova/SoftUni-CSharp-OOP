﻿namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            //List<Mammal> list = new List<Mammal>();
            //list.Add(new Gorilla("Pesho"));
            //list.Add(new Bear("Pasha"));

            //foreach (var mammal in list)
            //{
            //    mammal.ProduceMilk();
            //}
        }
    }
}
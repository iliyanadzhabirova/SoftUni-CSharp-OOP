﻿namespace Vehicles.Models.Interfaces
{
    public interface IRefueable
    {
        void Refuel(double amount);
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.MilitaryElite.Interfaces
{
    public interface ISpecialisedSoldier
    {
        public string Corps { get; set; }
    }
}
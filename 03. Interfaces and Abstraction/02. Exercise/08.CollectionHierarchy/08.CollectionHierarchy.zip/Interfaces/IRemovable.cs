﻿namespace _08.CollectionHierarchy.Interfaces
{
    public interface IRemovable
    {
        string Remove();
    }
}

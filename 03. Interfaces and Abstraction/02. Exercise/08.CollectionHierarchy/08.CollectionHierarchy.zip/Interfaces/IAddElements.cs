﻿namespace _08.CollectionHierarchy.Interfaces
{
    public interface IAddElements
    {
        int Add(string input);
    }
}

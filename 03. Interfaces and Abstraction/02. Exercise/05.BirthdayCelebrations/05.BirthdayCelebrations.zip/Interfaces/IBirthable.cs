﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.BirthdayCelebrations.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
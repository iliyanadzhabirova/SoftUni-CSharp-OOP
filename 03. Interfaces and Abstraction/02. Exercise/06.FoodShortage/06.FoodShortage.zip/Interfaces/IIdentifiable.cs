﻿namespace _06.FoodShortage.Interfaces
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
﻿namespace _06.FoodShortage.Interfaces
{
    public interface IBirthable
    {
        string Birthdate { get; }
    }
}
﻿using _06.FoodShortage.Interfaces;

namespace _06.FoodShortage.Models
{
    public class Robot : IIdentifiable
    {
        public string Model { get; private set; }
        public string Id { get; private set; }

        public Robot(string model, string id)
        {
            Model = model;
            Id = id;
        }
    }
}